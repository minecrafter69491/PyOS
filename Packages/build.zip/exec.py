def frun():
    ...
import zipfile
import os
def zip_directory(source_dir, zip_path):
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(source_dir):
            for file in files:
                abs_path = os.path.join(root, file)
                rel_path = os.path.relpath(abs_path, source_dir)
                zipf.write(abs_path, rel_path)
def main(args):
    pkg_name = args[0]
    print(f"[info] Building package: {pkg_name}")
    pkg_path = os.path.join(os.getcwd(), pkg_name)
    if not os.path.exists(pkg_path) or not os.path.isdir(pkg_path):
        print(f"[error] directory '{pkg_name}' not found.")
        return
    zip_directory(pkg_path, f"{pkg_name}.zip")
    print(f"[done] {pkg_name}.zip created in the current directory.")
    