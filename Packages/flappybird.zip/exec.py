def frun():
    ...

def main(args):
	import game
import sys, pathlib, os
script_path = pathlib.Path(__file__).resolve()
script_dir = script_path.parent
dir = os.path.abspath(script_dir)
sys.path.insert(0, dir)
