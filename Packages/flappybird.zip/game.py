import os
import time
import random
import msvcrt

# Game constants
HEIGHT = 10
WIDTH = 30
BIRD = 'O'
PIPE = '|'
EMPTY = ' '
TICK = 0.3

# Initial game state
bird_y = HEIGHT // 2
pipes = []
score = 0
frame = 0

def clear():
    os.system('cls')

def draw():
    global pipes, bird_y, score
    for y in range(HEIGHT):
        line = ''
        for x in range(WIDTH):
            # Draw bird
            if x == 5 and y == bird_y:
                line += BIRD
            # Draw pipes
            elif any(p[0] == x and (y < p[1] or y > p[1]+2) for p in pipes):
                line += PIPE
            else:
                line += EMPTY
        print(line)
    print(f"Score: {score}")

def update_pipes():
    global pipes, score
    new_pipes = []
    for p in pipes:
        p[0] -= 1
        if p[0] >= 0:
            new_pipes.append(p)
        else:
            score += 1
    pipes = new_pipes
    if frame % 20 == 0:
        gap_y = random.randint(1, HEIGHT-4)
        pipes.append([WIDTH-1, gap_y])

def check_collision():
    for p in pipes:
        if p[0] == 5 and (bird_y < p[1] or bird_y > p[1]+2):
            return True
    if bird_y < 0 or bird_y >= HEIGHT:
        return True
    return False

# Game loop
try:
    while True:
        frame += 1
        clear()
        draw()
        update_pipes()
        if check_collision():
            print("Game Over!")
            break

        # Input with timeout
        start_time = time.time()
        inp = None
        while time.time() - start_time < TICK:
            if msvcrt.kbhit():
                msvcrt.getch()  # consume key
                inp = True
                break

        # Flap on key press
        if inp:
            bird_y -= 1
        else:
            bird_y += 1

except KeyboardInterrupt:
    pass
