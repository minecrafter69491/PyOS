import os
import json
root = os.environ.get('ROOTFS')
CONFIG_FILE = os.path.join(root,'usr','ark', "ark_config.json")


def load_config():
    if os.path.isfile(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            try:
                return json.load(f)
            except Exception:
                return {}
    return {}

def save_config(config):
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)

def cmd_set(args, variables):
    if len(args) < 2:
        print("set: usage: set <key> <value>")
        return
    key, value = args[0], " ".join(args[1:])
    config = load_config()
    config[key] = value
    save_config(config)
    print(f"Set {key} = {value} in {CONFIG_FILE}")

def cmd_get(args, variables):
    if not args:
        print("get: usage: get <key>")
        return
    key = args[0]
    config = load_config()
    if key in config:
        print(config[key])
    else:
        print(f"get: key '{key}' not found in {CONFIG_FILE}")
def cmd_input(args, variables):
    if not args:
        var_name = "input"
        prompt = ""
    else:
        var_name = args[0]
        prompt = " ".join(args[1:]) if len(args) > 1 else ""
    user_input = input(prompt)
    variables[var_name] = user_input

def parse_line(line, variables):
    tokens = line.strip().split()
    if not tokens:
        return
    if tokens[0] == "print":
        expr = " ".join(tokens[1:])
        print(eval(expr, {}, variables))
    elif tokens[0] in custom_commands:
        custom_commands[tokens[0]](tokens[1:], variables)
    elif "=" in tokens:
        var_index = tokens.index("=")
        var_name = tokens[var_index - 1]
        expr = " ".join(tokens[var_index + 1:])
        variables[var_name] = eval(expr, {}, variables)
    else:
        print(f"Unknown command: {line}")

def run_ark(filename):
    variables = custom_commands.copy()
    with open(filename) as f:
        for line in f:
            parse_line(line, variables)

def cmd_run(args, variables):
    if not args:
        print("run: missing filename")
        return
    filename = args[0]
    if not os.path.isfile(filename):
        print(f"run: file not found: {filename}")
        return
    try:
        run_ark(filename)
    except Exception as e:
        print(f"run error: {e}")


import sys
import os
import subprocess
import json
import io
import contextlib
def cmd_ls(args, variables):
    path = args[0] if args else "."
    try:
        for entry in os.listdir(path):
            print(entry)
    except Exception as e:
        print(f"ls error: {e}")

def cmd_restart(args, variables):
    print("Restarting")
    try:
        main()
    except Exception as e:
        print(f"restart error: {e}")

def cmd_del(args, variables):
    if not args:
        print("del: missing filename")
        return
    try:
        os.remove(args[0])
        print(f"Deleted {args[0]}")
    except Exception as e:
        print(f"del error: {e}")

def cmd_restart(args, variables):
    print("Restarting interpreter...")
    os.execv(sys.executable, [sys.executable] + sys.argv)

def cmd_rs323(args, variables):
    print("RS323 command not implemented (stub)")

def cmd_nettool(args, variables):
    print("Nettool command not implemented (stub)")
def cmd_authorise(args, variables):
    print("Authorise is a deprecated command and will be removed in future versions.")

custom_commands = {
    "ls": cmd_ls,
    "del": cmd_del,
    "restart": cmd_restart,
    "rs323": cmd_rs323,
    "nettool": cmd_nettool,
    "authorise": cmd_authorise,
    "run": cmd_run,
    "print": lambda args, variables: print(" ".join(args)),
    "help": lambda args, variables: print("Available commands: " + ", ".join(custom_commands.keys())),
    "exit": lambda args, variables: sys.exit(0),
    "quit": lambda args, variables: sys.exit(0),
    "clear": lambda args, variables: os.system('cls' if os.name == 'nt' else 'clear'),
    "version": lambda args, variables: print("ARK Interpreter v1.0"),
    "echo": lambda args, variables: print(" ".join(args)),
    "set": cmd_set,
    "get": cmd_get,
    "input": cmd_input,
}   
def main():
    if len(sys.argv) > 1:
        run_ark(sys.argv[1])
        sys.exit(0)
    variables = {}
    print("Welcome to the ARK Interpreter!")
    print("Type 'help' for a list of commands.")
    print("Type 'exit' or 'quit' to exit the interpreter.")
    while True:
        try:
            line = input("ark> ")
            tokens = line.strip().split()
            if not tokens:
                continue
            cmd = tokens[0]
            args = tokens[1:]
            if cmd in custom_commands:
                custom_commands[cmd](args, variables)
            else:
                print(f"Unknown command: {cmd}")
        except (EOFError, KeyboardInterrupt):
            print("\nExiting ARK Interpreter.")
            break
def frun():
    ...