def frun():
    ...
def main(args):
    pkg_name = args[0]
    import os
    os.mkdir(pkg_name)
    with open(os.path.join(pkg_name, 'exec.py'), 'w') as f:
        f.write('def frun():\n    ...\n\ndef main(args):\n    ...\n')
    print(f"Package '{pkg_name}' created successfully.")
    return 0